from django.apps import AppConfig


class Dz4Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dz4'
