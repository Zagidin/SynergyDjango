from django.contrib import admin
from .models import Category, Manufacturer


admin.site.register(Category)
admin.site.register(Manufacturer)
